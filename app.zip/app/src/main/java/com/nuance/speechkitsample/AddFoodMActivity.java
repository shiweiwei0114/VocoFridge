package com.nuance.speechkitsample;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddFoodMActivity extends Activity {

    private EditText mAddFoodName;
    private EditText mAddFoodQuantity;
    private Button mAddButton;

    public static final String FOODNAME = "FOODUNIQUE";
    public static final String FOODQUANTITY = "FOODUNIQUE2";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_food_m);


        //Find the add button
        mAddButton = (Button)findViewById(R.id.add_Food_Button);
        mAddButton.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View arg0) {
                        Intent i = new Intent(AddFoodMActivity.this,
                                ListActivity.class);
                        String FoodName = mAddFoodName.toString();
                        String FoodQuantity = mAddFoodQuantity.toString();
                        i.putExtra(FOODNAME, FoodName);
                        i.putExtra(FOODQUANTITY, FoodQuantity);
                        startActivity(i);
                        finish();
                    }
                }
        );
    }

}
