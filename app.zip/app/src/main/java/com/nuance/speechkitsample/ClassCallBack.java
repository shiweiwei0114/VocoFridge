package com.nuance.speechkitsample;

/**
 * Created by shiwe on 7/30/2016.
 */
public interface ClassCallBack {

    void callBack(String thePassInData);
}
