package com.nuance.speechkitsample;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.nuance.speechkit.Audio;
import com.nuance.speechkit.DetectionType;
import com.nuance.speechkit.Interpretation;
import com.nuance.speechkit.Language;
import com.nuance.speechkit.Recognition;
import com.nuance.speechkit.Session;
import com.nuance.speechkit.Transaction;
import com.nuance.speechkit.TransactionException;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ListActivity extends DetailActivity {

    private State state = State.IDLE;
    private SQLiteDatabaseHelper myFoodDB;
    private Session speechSession;
    private Transaction recoTransaction;
    Button nluButton = null;
    private ProgressBar volumeBar;
    private Audio startEarcon;
    private Audio stopEarcon;
    private Audio errorEarcon;

    //Manual add button
    private Button mAddButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        myFoodDB = new SQLiteDatabaseHelper(this, "foodTable");
//        System.out.println(addFood("Chicken breast", 2));
//        System.out.println(addFood("milk", 4));
//        System.out.println(addFood("Beef", 3));
//        System.out.println(addFood("apples", 7));
//        System.out.println(addFood("chocolate", 2));
//        System.out.println(addFood("Tofu", 9));
//        System.out.println(addFood("Tomato", 8));

        String tempArray = getAllFoodRecord();
        String[] foodRecord = tempArray.split(",");

        //------------------------------
        speechSession = Session.Factory.session(this, Configuration.SERVER_URI, Configuration.APP_KEY);
        volumeBar = (ProgressBar)findViewById(R.id.volume_bar);

        ListView foodList = (ListView) findViewById(R.id.food_list);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(foodList.getContext(), android.R.layout.simple_list_item_1, foodRecord);
        foodList.setAdapter(myAdapter);

        nluButton = (Button) findViewById(R.id.button);
        nluButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent myIntent = null;
//                myIntent = new Intent(ListActivity.this, NLUActivity.class);
//                startActivity(myIntent);

                toggleReco();
            }
        });

        mAddButton = (Button) findViewById(R.id.Manual_button);
        mAddButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = null;
                i = new Intent(ListActivity.this, AddFoodMActivity.class);
                startActivity(i);
            }
        });

        loadEarcons();

        setState(State.IDLE);

//        Bundle extra = getIntent().getExtras();
//        String foodName = extra.getString(AddFoodMActivity.FOODNAME);
//        myAdapter.add(foodName);
//
//        String foodQuantity = extra.getString(AddFoodMActivity.FOODQUANTITY);
//        myAdapter.add(foodQuantity);
    }

    public boolean addFood(String food_Name, int food_quantity){

        Calendar myCal = Calendar.getInstance();
        //System.out.println("Current time => " + myCal.getTime());
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String formattedDate = df.format(myCal.getTime());

        boolean isFoodAdded = myFoodDB.addFoodRecord(food_Name, food_quantity, formattedDate);
        if(isFoodAdded){  // = true
            Toast.makeText(this, "Food record added", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "Food hasn't added", Toast.LENGTH_LONG).show();
        }
        return isFoodAdded;
    }

    public void deleteFood(String food_Name){
        int delete = myFoodDB.deleteData(food_Name); // delete by id
        if(delete > 0){ // delete is number of row that got delete
            Toast.makeText(this, "Delete", Toast.LENGTH_LONG).show();
        }else {
            Toast.makeText(this, "Not be able to Delete", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * To save all the user favorite dish data into arraylist to pass to MyCustomAdapter
     * to display on the listview.
     */
    public String getAllFoodRecord() {
        StringBuilder sb = new StringBuilder();
        Cursor res = myFoodDB.getAllFoodRecord();
        if (res.getCount() == 0) {
            Toast.makeText(this, "No Data", Toast.LENGTH_LONG).show();
        } else {
            // print list
            if (res.moveToFirst()) {
                do {
                    sb.append(res.getString(1));
                    sb.append(" ");
                    sb.append(res.getInt(2));
                    sb.append(" ");
                    sb.append(res.getString(3));
                    sb.append(",");
                } while (res.moveToNext());
            }
        }
        return sb.toString();
    }

    public void toggleReco() {
        switch (state) {
            case IDLE:
                System.out.println("I am in!");
                recognize();
                break;
            case LISTENING:
                stopRecording();
                break;
            case PROCESSING:
                cancel();
                break;
        }
    }

    /**
     * Start listening to the user and streaming their voice to the server.
     */
    private void recognize() {
        //Setup our Reco transaction options.
        Transaction.Options options = new Transaction.Options();
        options.setDetection(resourceIDToDetectionType("R.id.short_endpoint"));
        options.setLanguage(new Language("eng-USA"));
        options.setEarcons(startEarcon, stopEarcon, errorEarcon, null);

        //Add properties to appServerData for use with custom service. Leave empty for use with NLU.
        JSONObject appServerData = new JSONObject();
        //Start listening
        recoTransaction = speechSession.recognizeWithService("M3259_A1649_V1", appServerData, options, recoListener);
    }

        private Transaction.Listener recoListener = new Transaction.Listener() {
        public void onStartedRecording(Transaction transaction) {
            System.out.println(("\nonStartedRecording"));

            //We have started recording the users voice.
            //We should update our state and start polling their volume.
            setState(State.LISTENING);
            startAudioLevelPoll();
        }

        @Override
        public void onFinishedRecording(Transaction transaction) {
            System.out.println(("\nonFinishedRecording"));

            //We have finished recording the users voice.
            //We should update our state and stop polling their volume.
            setState(State.PROCESSING);
            stopAudioLevelPoll();
        }

        @Override
        public void onServiceResponse(Transaction transaction, org.json.JSONObject response) {
            try {
                // 2 spaces for tabulations.
                System.out.println(("\nonServiceResponse: " + response.toString(2)));
            } catch (JSONException e) {
                e.printStackTrace();
            }

            // We have received a service response. In this case it is our NLU result.
            // Note: this will only happen if you are doing NLU (or using a service)
            setState(State.IDLE);
        }

        @Override
        public void onRecognition(Transaction transaction, Recognition recognition) {
            System.out.println(("\nonRecognition: " + recognition.getText()));

            //We have received a transcription of the users voice from the server.
            setState(State.IDLE);
        }

        @Override
        public void onInterpretation(Transaction transaction, Interpretation interpretation) {
            try {

                JSONObject jsonObj = new JSONObject(interpretation.getResult().toString(2));
                //JSONObject jsonObj = (JSONObject) JSONSerializer.toJSON(interpretation);
                System.out.println(interpretation.getResult().toString(2));
//                TextView temp = (TextView) findViewById(R.id.resultTextView);
//                temp.setText(interpretation.getResult().toString(2));
                //String food = jsonObj.getString("Food");
                //System.out.println("Hey yoyooyoyoyoy ------------------------------------------------------");
                //System.out.println("Food is : " + food);

//                String number = jsonObj.getJSONObject("interpretations").getString("interpretations");
//                System.out.println("The Food is : " + number);
//
//                String foodName = jsonObj.getJSONObject("NUMBER").getString("literal");
//                System.out.println("The food name is : " + number);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            // We have received a service response. In this case it is our NLU result.
            // Note: this will only happen if you are doing NLU (or using a service)
            setState(State.IDLE);
        }

        @Override
        public void onSuccess(Transaction transaction, String s) {
            System.out.println(("\nonSuccess"));

            //Notification of a successful transaction. Nothing to do here.
        }

        @Override
        public void onError(Transaction transaction, String s, TransactionException e) {
            System.out.println(("\nonError: " + e.getMessage() + ". " + s));

            //Something went wrong. Check Configuration.java to ensure that your settings are correct.
            //The user could also be offline, so be sure to handle this case appropriately.
            //We will simply reset to the idle state.
            setState(State.IDLE);
        }
    };

    /**
     * Stop recording the user
     */
    private void stopRecording() {
        recoTransaction.stopRecording();
    }

    /**
     * Cancel the Reco transaction.
     * This will only cancel if we have not received a response from the server yet.
     */
    private void cancel() {
        recoTransaction.cancel();
    }

    /* Audio Level Polling */

    private Handler handler = new Handler();

    /**
     * Every 50 milliseconds we should update the volume meter in our UI.
     */
    private Runnable audioPoller = new Runnable() {
        @Override
        public void run() {
            float level = recoTransaction.getAudioLevel();
            volumeBar.setProgress((int)level);
            handler.postDelayed(audioPoller, 50);
        }
    };

    /**
     * Start polling the users audio level.
     */
    private void startAudioLevelPoll() {
        audioPoller.run();
    }

    /**
     * Stop polling the users audio level.
     */
    private void stopAudioLevelPoll() {
        handler.removeCallbacks(audioPoller);
        volumeBar.setProgress(0);
    }


    /* State Logic: IDLE -> LISTENING -> PROCESSING -> repeat */

    private enum State {
        IDLE,
        LISTENING,
        PROCESSING
    }

    /**
     * Set the state and update the button text.
     */
    private void setState(State newState) {
        state = newState;
        switch (newState) {
            case IDLE:
                nluButton.setText(getResources().getString(R.string.recognize_with_service));
                break;
            case LISTENING:
                nluButton.setText(getResources().getString(R.string.listening));
                break;
            case PROCESSING:
                nluButton.setText(getResources().getString(R.string.processing));
                break;
        }
    }

    /* Earcons */

    private void loadEarcons() {
        //Load all of the earcons from disk
        startEarcon = new Audio(this, R.raw.sk_start, Configuration.PCM_FORMAT);
        stopEarcon = new Audio(this, R.raw.sk_stop, Configuration.PCM_FORMAT);
        errorEarcon = new Audio(this, R.raw.sk_error, Configuration.PCM_FORMAT);
    }

    /* Helpers */

    private DetectionType resourceIDToDetectionType(String theEndPointType) {
        if(theEndPointType.equals("R.id.long_endpoint")) {
            return DetectionType.Long;
        }
        if(theEndPointType.equals("R.id.short_endpoint")) {
            System.out.println("Hello, I am returning DetectionType.Short");
            return DetectionType.Short;
        }
        if(theEndPointType.equals("R.id.none")) {
            return DetectionType.None;
        }
        return null;
    }
}
