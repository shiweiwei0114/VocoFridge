package com.nuance.speechkitsample;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by sawet
 * To save data of each dish into local memory.
 */
public class SQLiteDatabaseHelper extends SQLiteOpenHelper {

    // Declare variable that needed in this Activity
    public static final String DATABASE_NAME = "friTacker.db";
    public static String TABLE_NAME;
    public static final String column_1 = "Food_ID";
    public static final String column_2 = "Food_Name";
    public static final String column_3 = "Food_quantity";
    public static final String column_4 = "Food_BoughtDate";

    /**
     * this will create database table on devise
     * @param context
     */
    public SQLiteDatabaseHelper(Context context, String tableName) {
        super(context, DATABASE_NAME, null, 1);
        TABLE_NAME = tableName;
        SQLiteDatabase db = this.getWritableDatabase();
        onCreate(db);
    }

    /**
     * create table construct and data on devise
     * @param db
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table if not exists " + TABLE_NAME +" (" + column_1 + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                column_2 +" TEXT," + column_3 +" INTEGER," + column_4 +" INTEGER)");
    }

    /**
     * onUpgrade check if table exists before.
     * @param db SQLiteDatabase
     * @param oldVersion version
     * @param newVersion version
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        onCreate(db);
    }

    public boolean addFoodRecord(String food_Name, int food_quantity, String food_BoughtDate){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(column_2, food_Name);
        contentValues.put(column_3, food_quantity);
        contentValues.put(column_4, food_BoughtDate);

        // insert data to table
        long result = db.insert(TABLE_NAME, null, contentValues);
        if(result == -1){
            return false;
        } else {
            return true;
        }
    }

    /**
     * Put all the data from the table into Cursor to be display when it call.
     * @return Cursor.
     */
    public Cursor getAllFoodRecord(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLE_NAME, null);
        return res;
    }

    /**
     * To delete data from the table by foodID.
     * @param foodID foood id
     * @return int
     */
    public int deleteData(String food_Name){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "food_Name = ?", new String[]{food_Name});
    }

}
